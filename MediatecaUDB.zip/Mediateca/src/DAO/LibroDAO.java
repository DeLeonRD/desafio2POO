package DAO;

import model.Libro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de Libro. Inserta en 3 tablas (material, material_escrito, libro)
 * dentro de una transacción. Para listar/buscar hace JOIN de las 3.
 */
public class LibroDAO extends MaterialDAO<Libro> {

    @Override
    public int insertar(Libro libro) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;

        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            // 1. Generar código correlativo (ej: LIB00003)
            String codigo = generarCodigo(conn, "LIB");
            libro.setCodigoIdentificacion(codigo);

            // 2. INSERT en material
            int idMaterial = insertarMaterial(conn, codigo, libro.getTitulo(),
                    libro.getUnidadesDisponibles(), "LIBRO");
            libro.setId(idMaterial);

            // 3. INSERT en material_escrito
            insertarMaterialEscrito(conn, idMaterial, libro.getEditorial());

            // 4. INSERT en libro
            String sql = "INSERT INTO libro (id_material, autor, numero_paginas, isbn, anio_publicacion) " +
                         "VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idMaterial);
                ps.setString(2, libro.getAutor());
                ps.setInt(3, libro.getNumeroPaginas());
                ps.setString(4, libro.getIsbn());
                ps.setInt(5, libro.getAnioPublicacion());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✔ Libro insertado. ID=" + idMaterial + ", código=" + codigo);
            return idMaterial;

        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("❌ Error al insertar libro: " + e.getMessage());
            return -1;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    @Override
    public List<Libro> listar() {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "me.editorial, l.autor, l.numero_paginas, l.isbn, l.anio_publicacion " +
                     "FROM material m " +
                     "JOIN material_escrito me ON m.id_material = me.id_material " +
                     "JOIN libro l ON me.id_material = l.id_material " +
                     "ORDER BY m.id_material";

        try (PreparedStatement ps = getConexion().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapearLibro(rs));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al listar libros: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public Libro buscarPorId(int id) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "me.editorial, l.autor, l.numero_paginas, l.isbn, l.anio_publicacion " +
                     "FROM material m " +
                     "JOIN material_escrito me ON m.id_material = me.id_material " +
                     "JOIN libro l ON me.id_material = l.id_material " +
                     "WHERE m.id_material = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearLibro(rs);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar libro id=" + id + ": " + e.getMessage());
        }
        return null;
    }

    public Libro buscarPorCodigo(String codigo) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "me.editorial, l.autor, l.numero_paginas, l.isbn, l.anio_publicacion " +
                     "FROM material m " +
                     "JOIN material_escrito me ON m.id_material = me.id_material " +
                     "JOIN libro l ON me.id_material = l.id_material " +
                     "WHERE m.codigo_identificacion = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearLibro(rs);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar libro codigo=" + codigo + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean actualizar(Libro libro) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;
        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            // Material
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material SET titulo=?, unidades_disponibles=? WHERE id_material=?")) {
                ps.setString(1, libro.getTitulo());
                ps.setInt(2, libro.getUnidadesDisponibles());
                ps.setInt(3, libro.getId());
                ps.executeUpdate();
            }
            // Material_escrito
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material_escrito SET editorial=? WHERE id_material=?")) {
                ps.setString(1, libro.getEditorial());
                ps.setInt(2, libro.getId());
                ps.executeUpdate();
            }
            // Libro
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE libro SET autor=?, numero_paginas=?, isbn=?, anio_publicacion=? WHERE id_material=?")) {
                ps.setString(1, libro.getAutor());
                ps.setInt(2, libro.getNumeroPaginas());
                ps.setString(3, libro.getIsbn());
                ps.setInt(4, libro.getAnioPublicacion());
                ps.setInt(5, libro.getId());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✔ Libro actualizado id=" + libro.getId());
            return true;
        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("❌ Error al actualizar libro: " + e.getMessage());
            return false;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    private Libro mapearLibro(ResultSet rs) throws SQLException {
        Libro l = new Libro();
        l.setId(rs.getInt("id_material"));
        l.setCodigoIdentificacion(rs.getString("codigo_identificacion"));
        l.setTitulo(rs.getString("titulo"));
        l.setUnidadesDisponibles(rs.getInt("unidades_disponibles"));
        l.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        l.setEditorial(rs.getString("editorial"));
        l.setAutor(rs.getString("autor"));
        l.setNumeroPaginas(rs.getInt("numero_paginas"));
        l.setIsbn(rs.getString("isbn"));
        l.setAnioPublicacion(rs.getInt("anio_publicacion"));
        return l;
    }
}