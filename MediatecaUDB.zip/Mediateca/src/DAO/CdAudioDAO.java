package DAO;

import model.CdAudio;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de CD de Audio. Inserta en 3 tablas (material, material_audiovisual, cd_audio)
 */

public class CdAudioDAO extends MaterialDAO<CdAudio> {

    @Override
    public int insertar(CdAudio cd) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;

        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

// 1. Generar código
            String codigo = generarCodigo(conn, "CDA");
            cd.setCodigoIdentificacion(codigo);

// 2. INSERT en material
            int idMaterial = insertarMaterial(conn, codigo, cd.getTitulo(),
                    cd.getUnidadesDisponibles(), "CD_AUDIO");
            cd.setId(idMaterial);

// 3. INSERT en material_audiovisual
            insertarMaterialAudiovisual(conn, idMaterial, cd.getDuracion(), cd.getGenero());

// 4. INSERT en cd_audio
            String sql = "INSERT INTO cd_audio (id_material, artista, numero_canciones) " +
                         "VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idMaterial);
                ps.setString(2, cd.getArtista());
                ps.setInt(3, cd.getNumeroCanciones());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("CD insertado. ID=" + idMaterial + ", código=" + codigo);
            return idMaterial;

        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("Error al insertar CD: " + e.getMessage());
            return -1;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    @Override
    public List<CdAudio> listar() {
        List<CdAudio> lista = new ArrayList<>();
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "ma.duracion, ma.genero, c.artista, c.numero_canciones " +
                     "FROM material m " +
                     "JOIN material_audiovisual ma ON m.id_material = ma.id_material " +
                     "JOIN cd_audio c ON ma.id_material = c.id_material " +
                     "ORDER BY m.id_material";

        try (PreparedStatement ps = getConexion().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapearCd(rs));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al listar CDs: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public CdAudio buscarPorId(int id) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "ma.duracion, ma.genero, c.artista, c.numero_canciones " +
                     "FROM material m " +
                     "JOIN material_audiovisual ma ON m.id_material = ma.id_material " +
                     "JOIN cd_audio c ON ma.id_material = c.id_material " +
                     "WHERE m.id_material = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearCd(rs);
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar CD id=" + id + ": " + e.getMessage());
        }
        return null;
    }

    public CdAudio buscarPorCodigo(String codigo) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "ma.duracion, ma.genero, c.artista, c.numero_canciones " +
                     "FROM material m " +
                     "JOIN material_audiovisual ma ON m.id_material = ma.id_material " +
                     "JOIN cd_audio c ON ma.id_material = c.id_material " +
                     "WHERE m.codigo_identificacion = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearCd(rs);
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar CD codigo=" + codigo + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean actualizar(CdAudio cd) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;
        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material SET titulo=?, unidades_disponibles=? WHERE id_material=?")) {
                ps.setString(1, cd.getTitulo());
                ps.setInt(2, cd.getUnidadesDisponibles());
                ps.setInt(3, cd.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material_audiovisual SET duracion=?, genero=? WHERE id_material=?")) {
                ps.setString(1, cd.getDuracion());
                ps.setString(2, cd.getGenero());
                ps.setInt(3, cd.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE cd_audio SET artista=?, numero_canciones=? WHERE id_material=?")) {
                ps.setString(1, cd.getArtista());
                ps.setInt(2, cd.getNumeroCanciones());
                ps.setInt(3, cd.getId());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✔ CD actualizado id=" + cd.getId());
            return true;
        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("Error al actualizar CD: " + e.getMessage());
            return false;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    private CdAudio mapearCd(ResultSet rs) throws SQLException {
        CdAudio c = new CdAudio();
        c.setId(rs.getInt("id_material"));
        c.setCodigoIdentificacion(rs.getString("codigo_identificacion"));
        c.setTitulo(rs.getString("titulo"));
        c.setUnidadesDisponibles(rs.getInt("unidades_disponibles"));
        c.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        c.setDuracion(rs.getString("duracion"));
        c.setGenero(rs.getString("genero"));
        c.setArtista(rs.getString("artista"));
        c.setNumeroCanciones(rs.getInt("numero_canciones"));
        return c;
    }
}
