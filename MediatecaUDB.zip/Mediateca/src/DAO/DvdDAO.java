package DAO;

import model.Dvd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de DVD. Inserta en 3 tablas (material, material_audiovisual, dvd)
 * dentro de una transacción.
 */
public class DvdDAO extends MaterialDAO<Dvd> {

    @Override
    public int insertar(Dvd dvd) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;

        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            // 1. Generar código
            String codigo = generarCodigo(conn, "DVD");
            dvd.setCodigoIdentificacion(codigo);

            // 2. INSERT en material
            int idMaterial = insertarMaterial(conn, codigo, dvd.getTitulo(),
                    dvd.getUnidadesDisponibles(), "DVD");
            dvd.setId(idMaterial);

            // 3. INSERT en material_audiovisual
            insertarMaterialAudiovisual(conn, idMaterial, dvd.getDuracion(), dvd.getGenero());

            // 4. INSERT en dvd
            String sql = "INSERT INTO dvd (id_material, director) VALUES (?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idMaterial);
                ps.setString(2, dvd.getDirector());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✔ DVD insertado. ID=" + idMaterial + ", código=" + codigo);
            return idMaterial;

        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("❌ Error al insertar DVD: " + e.getMessage());
            return -1;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    @Override
    public List<Dvd> listar() {
        List<Dvd> lista = new ArrayList<>();
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "ma.duracion, ma.genero, d.director " +
                     "FROM material m " +
                     "JOIN material_audiovisual ma ON m.id_material = ma.id_material " +
                     "JOIN dvd d ON ma.id_material = d.id_material " +
                     "ORDER BY m.id_material";

        try (PreparedStatement ps = getConexion().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapearDvd(rs));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al listar DVDs: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public Dvd buscarPorId(int id) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "ma.duracion, ma.genero, d.director " +
                     "FROM material m " +
                     "JOIN material_audiovisual ma ON m.id_material = ma.id_material " +
                     "JOIN dvd d ON ma.id_material = d.id_material " +
                     "WHERE m.id_material = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearDvd(rs);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar DVD id=" + id + ": " + e.getMessage());
        }
        return null;
    }

    public Dvd buscarPorCodigo(String codigo) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "ma.duracion, ma.genero, d.director " +
                     "FROM material m " +
                     "JOIN material_audiovisual ma ON m.id_material = ma.id_material " +
                     "JOIN dvd d ON ma.id_material = d.id_material " +
                     "WHERE m.codigo_identificacion = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearDvd(rs);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar DVD codigo=" + codigo + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean actualizar(Dvd dvd) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;
        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material SET titulo=?, unidades_disponibles=? WHERE id_material=?")) {
                ps.setString(1, dvd.getTitulo());
                ps.setInt(2, dvd.getUnidadesDisponibles());
                ps.setInt(3, dvd.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material_audiovisual SET duracion=?, genero=? WHERE id_material=?")) {
                ps.setString(1, dvd.getDuracion());
                ps.setString(2, dvd.getGenero());
                ps.setInt(3, dvd.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE dvd SET director=? WHERE id_material=?")) {
                ps.setString(1, dvd.getDirector());
                ps.setInt(2, dvd.getId());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✔ DVD actualizado id=" + dvd.getId());
            return true;
        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("❌ Error al actualizar DVD: " + e.getMessage());
            return false;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    private Dvd mapearDvd(ResultSet rs) throws SQLException {
        Dvd d = new Dvd();
        d.setId(rs.getInt("id_material"));
        d.setCodigoIdentificacion(rs.getString("codigo_identificacion"));
        d.setTitulo(rs.getString("titulo"));
        d.setUnidadesDisponibles(rs.getInt("unidades_disponibles"));
        d.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        d.setDuracion(rs.getString("duracion"));
        d.setGenero(rs.getString("genero"));
        d.setDirector(rs.getString("director"));
        return d;
    }
}
