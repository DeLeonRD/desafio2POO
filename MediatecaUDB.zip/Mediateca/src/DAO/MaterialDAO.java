package DAO;

import db.DatabaseConnection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.List;

/**
 * Clase base abstracta para todos los DAO del sistema Mediateca.
 * Proporciona la conexión y contratos CRUD genéricos.
 *
 * Cada DAO concreto implementa la inserción en 3 pasos:
 *   1. generar_codigo (stored procedure)
 *   2. INSERT en material
 *   3. INSERT en material_escrito o material_audiovisual
 *   4. INSERT en tabla específica (libro/revista/cd_audio/dvd)
 * Todo envuelto en una transacción.
 *
 * @param <T> tipo del modelo que maneja el DAO
 */
public abstract class MaterialDAO<T> {

    protected Connection getConexion() {
        return DatabaseConnection.getInstancia().getConexion();
    }

    /** Inserta un objeto y devuelve el id generado, o -1 si falla. */
    public abstract int insertar(T obj);

    /** Lista todos los registros. */
    public abstract List<T> listar();

    /** Busca un registro por su id_material. Devuelve null si no existe. */
    public abstract T buscarPorId(int id);

    /** Actualiza un registro existente. Devuelve true si tuvo éxito. */
    public abstract boolean actualizar(T obj);

    /** Elimina un registro por su id_material. Devuelve true si se eliminó. */
    public boolean eliminar(int id) {
        // El ON DELETE CASCADE en la BD borra automáticamente las filas hijas.
        String sql = "DELETE FROM material WHERE id_material = ?";
        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar material id=" + id + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * Llama al stored procedure generar_codigo para obtener
     * el siguiente código correlativo (ej: LIB00003).
     *
     * @param conn conexión activa (debe estar dentro de la transacción)
     * @param tipo uno de: LIB, REV, CDA, DVD
     * @return código generado
     */
    protected String generarCodigo(Connection conn, String tipo) throws SQLException {
        try (CallableStatement cs = conn.prepareCall("{CALL generar_codigo(?, ?)}")) {
            cs.setString(1, tipo);
            cs.registerOutParameter(2, Types.VARCHAR);
            cs.execute();
            return cs.getString(2);
        }
    }

    /**
     * Inserta en la tabla `material` y devuelve el id_material autogenerado.
     */
    protected int insertarMaterial(Connection conn, String codigo, String titulo,
                                   int unidades, String tipoMaterial) throws SQLException {
        String sql = "INSERT INTO material (codigo_identificacion, titulo, " +
                     "unidades_disponibles, tipo_material) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, codigo);
            ps.setString(2, titulo);
            ps.setInt(3, unidades);
            ps.setString(4, tipoMaterial);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }
        }
        throw new SQLException("No se pudo obtener el id generado de material");
    }

    /** Inserta en material_escrito. Llamar dentro de la misma transacción. */
    protected void insertarMaterialEscrito(Connection conn, int idMaterial, String editorial)
            throws SQLException {
        String sql = "INSERT INTO material_escrito (id_material, editorial) VALUES (?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idMaterial);
            ps.setString(2, editorial);
            ps.executeUpdate();
        }
    }

    /** Inserta en material_audiovisual. Llamar dentro de la misma transacción. */
    protected void insertarMaterialAudiovisual(Connection conn, int idMaterial,
                                               String duracion, String genero) throws SQLException {
        String sql = "INSERT INTO material_audiovisual (id_material, duracion, genero) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idMaterial);
            ps.setString(2, duracion);
            ps.setString(3, genero);
            ps.executeUpdate();
        }
    }
}