package DAO;

import model.Revista;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de Revista. Inserta en 3 tablas (material, material_escrito, revista)
 * dentro de una transacción.
 */
public class RevistaDAO extends MaterialDAO<Revista> {

    @Override
    public int insertar(Revista revista) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;

        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            // 1. Generar código
            String codigo = generarCodigo(conn, "REV");
            revista.setCodigoIdentificacion(codigo);

            // 2. INSERT en material
            int idMaterial = insertarMaterial(conn, codigo, revista.getTitulo(),
                    revista.getUnidadesDisponibles(), "REVISTA");
            revista.setId(idMaterial);

            // 3. INSERT en material_escrito
            insertarMaterialEscrito(conn, idMaterial, revista.getEditorial());

            // 4. INSERT en revista
            String sql = "INSERT INTO revista (id_material, periodicidad, fecha_publicacion) " +
                         "VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idMaterial);
                ps.setString(2, revista.getPeriodicidad());
                ps.setDate(3, revista.getFechaPublicacion());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✔ Revista insertada. ID=" + idMaterial + ", código=" + codigo);
            return idMaterial;

        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("❌ Error al insertar revista: " + e.getMessage());
            return -1;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    @Override
    public List<Revista> listar() {
        List<Revista> lista = new ArrayList<>();
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "me.editorial, r.periodicidad, r.fecha_publicacion " +
                     "FROM material m " +
                     "JOIN material_escrito me ON m.id_material = me.id_material " +
                     "JOIN revista r ON me.id_material = r.id_material " +
                     "ORDER BY m.id_material";

        try (PreparedStatement ps = getConexion().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapearRevista(rs));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al listar revistas: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public Revista buscarPorId(int id) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "me.editorial, r.periodicidad, r.fecha_publicacion " +
                     "FROM material m " +
                     "JOIN material_escrito me ON m.id_material = me.id_material " +
                     "JOIN revista r ON me.id_material = r.id_material " +
                     "WHERE m.id_material = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearRevista(rs);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar revista id=" + id + ": " + e.getMessage());
        }
        return null;
    }

    public Revista buscarPorCodigo(String codigo) {
        String sql = "SELECT m.id_material, m.codigo_identificacion, m.titulo, " +
                     "m.unidades_disponibles, m.fecha_registro, " +
                     "me.editorial, r.periodicidad, r.fecha_publicacion " +
                     "FROM material m " +
                     "JOIN material_escrito me ON m.id_material = me.id_material " +
                     "JOIN revista r ON me.id_material = r.id_material " +
                     "WHERE m.codigo_identificacion = ?";

        try (PreparedStatement ps = getConexion().prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearRevista(rs);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al buscar revista codigo=" + codigo + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean actualizar(Revista revista) {
        Connection conn = getConexion();
        boolean prevAutoCommit = true;
        try {
            prevAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material SET titulo=?, unidades_disponibles=? WHERE id_material=?")) {
                ps.setString(1, revista.getTitulo());
                ps.setInt(2, revista.getUnidadesDisponibles());
                ps.setInt(3, revista.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE material_escrito SET editorial=? WHERE id_material=?")) {
                ps.setString(1, revista.getEditorial());
                ps.setInt(2, revista.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE revista SET periodicidad=?, fecha_publicacion=? WHERE id_material=?")) {
                ps.setString(1, revista.getPeriodicidad());
                ps.setDate(2, revista.getFechaPublicacion());
                ps.setInt(3, revista.getId());
                ps.executeUpdate();
            }

            conn.commit();
            System.out.println("✔ Revista actualizada id=" + revista.getId());
            return true;
        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { /* ignorar */ }
            System.out.println("❌ Error al actualizar revista: " + e.getMessage());
            return false;
        } finally {
            try { conn.setAutoCommit(prevAutoCommit); } catch (SQLException ex) { /* ignorar */ }
        }
    }

    private Revista mapearRevista(ResultSet rs) throws SQLException {
        Revista r = new Revista();
        r.setId(rs.getInt("id_material"));
        r.setCodigoIdentificacion(rs.getString("codigo_identificacion"));
        r.setTitulo(rs.getString("titulo"));
        r.setUnidadesDisponibles(rs.getInt("unidades_disponibles"));
        r.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        r.setEditorial(rs.getString("editorial"));
        r.setPeriodicidad(rs.getString("periodicidad"));
        r.setFechaPublicacion(rs.getDate("fecha_publicacion"));
        return r;
    }
}
