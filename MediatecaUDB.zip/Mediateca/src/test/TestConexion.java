package test;

import DAO.CdAudioDAO;
import DAO.DvdDAO;
import DAO.LibroDAO;
import DAO.RevistaDAO;
import db.DatabaseConnection;
import model.CdAudio;
import model.Dvd;
import model.Libro;
import model.Revista;

import java.sql.Connection;
import java.sql.Date;
import java.sql.Statement;

/**
 * Prueba CRUD real contra la BD Mediateca.
 * Ejecutar con MySQL corriendo y config.properties bien configurado.
 */
public class TestConexion {

    public static void main(String[] args) {

        System.out.println("\n===== INICIO DE PRUEBAS CRUD =====\n");

        DatabaseConnection.getInstancia().getConexion();
        resetTablas();

        probarLibro();
        probarRevista();
        probarCd();
        probarDvd();

        System.out.println("\n===== LISTADO FINAL =====\n");
        System.out.println("[LIBROS]");
        new LibroDAO().listar().forEach(System.out::println);
        System.out.println("\n[REVISTAS]");
        new RevistaDAO().listar().forEach(System.out::println);
        System.out.println("\n[CDs]");
        new CdAudioDAO().listar().forEach(System.out::println);
        System.out.println("\n[DVDs]");
        new DvdDAO().listar().forEach(System.out::println);

        System.out.println("\n===== FIN DE PRUEBAS =====\n");
        DatabaseConnection.getInstancia().cerrarConexion();
    }

    // ========================= LIBRO =========================
    private static void probarLibro() {
        System.out.println("\n--- PRUEBA LIBRO ---");
        LibroDAO dao = new LibroDAO();

        Libro libro = new Libro();
        libro.setTitulo("El Quijote");
        libro.setUnidadesDisponibles(3);
        libro.setEditorial("Cátedra");
        libro.setAutor("Miguel de Cervantes");
        libro.setNumeroPaginas(863);
        libro.setIsbn("978-84-376-0494-7");
        libro.setAnioPublicacion(1605);

        // INSERT
        int id = dao.insertar(libro);
        if (id < 0) return;

        // BUSCAR
        Libro encontrado = dao.buscarPorId(id);
        System.out.println("Buscado: " + encontrado);

        // ACTUALIZAR
        encontrado.setUnidadesDisponibles(5);
        encontrado.setNumeroPaginas(900);
        dao.actualizar(encontrado);
        System.out.println("Después de actualizar: " + dao.buscarPorId(id));

        // Dejar un libro como prueba (no eliminamos para que quede en el listado final)
        // Para probar eliminar descomenta la siguiente línea:
        // dao.eliminar(id);
    }

    // ========================= REVISTA =========================
    private static void probarRevista() {
        System.out.println("\n--- PRUEBA REVISTA ---");
        RevistaDAO dao = new RevistaDAO();

        Revista revista = new Revista();
        revista.setTitulo("National Geographic - Diciembre");
        revista.setUnidadesDisponibles(4);
        revista.setEditorial("National Geographic Society");
        revista.setPeriodicidad("MENSUAL");
        revista.setFechaPublicacion(Date.valueOf("2025-12-01"));

        int id = dao.insertar(revista);
        if (id < 0) return;

        Revista encontrada = dao.buscarPorId(id);
        System.out.println("Buscado: " + encontrada);

        encontrada.setUnidadesDisponibles(6);
        dao.actualizar(encontrada);
        System.out.println("Después de actualizar: " + dao.buscarPorId(id));
    }

    // ========================= CD AUDIO =========================
    private static void probarCd() {
        System.out.println("\n--- PRUEBA CD ---");
        CdAudioDAO dao = new CdAudioDAO();

        CdAudio cd = new CdAudio();
        cd.setTitulo("Thriller");
        cd.setUnidadesDisponibles(2);
        cd.setDuracion("00:42:19");
        cd.setGenero("Pop");
        cd.setArtista("Michael Jackson");
        cd.setNumeroCanciones(9);

        int id = dao.insertar(cd);
        if (id < 0) return;

        CdAudio encontrado = dao.buscarPorId(id);
        System.out.println("Buscado: " + encontrado);

        encontrado.setUnidadesDisponibles(3);
        dao.actualizar(encontrado);
        System.out.println("Después de actualizar: " + dao.buscarPorId(id));
    }

    // ========================= DVD =========================
    private static void probarDvd() {
        System.out.println("\n--- PRUEBA DVD ---");
        DvdDAO dao = new DvdDAO();

        Dvd dvd = new Dvd();
        dvd.setTitulo("Inception");
        dvd.setUnidadesDisponibles(1);
        dvd.setDuracion("02:28:00");
        dvd.setGenero("Ciencia Ficción");
        dvd.setDirector("Christopher Nolan");

        int id = dao.insertar(dvd);
        if (id < 0) return;

        Dvd encontrado = dao.buscarPorId(id);
        System.out.println("Buscado: " + encontrado);

        encontrado.setUnidadesDisponibles(2);
        dao.actualizar(encontrado);
        System.out.println("Después de actualizar: " + dao.buscarPorId(id));
    }

    // ========================= RESET =========================
    private static void resetTablas() {
        try {
            Connection conn = DatabaseConnection.getInstancia().getConexion();
            Statement st = conn.createStatement();

            st.executeUpdate("SET FOREIGN_KEY_CHECKS = 0");
            // Orden: hijas primero, luego padres (aunque con FK_CHECKS=0 no importa)
            st.executeUpdate("TRUNCATE TABLE libro");
            st.executeUpdate("TRUNCATE TABLE revista");
            st.executeUpdate("TRUNCATE TABLE cd_audio");
            st.executeUpdate("TRUNCATE TABLE dvd");
            st.executeUpdate("TRUNCATE TABLE material_escrito");
            st.executeUpdate("TRUNCATE TABLE material_audiovisual");
            st.executeUpdate("TRUNCATE TABLE material");
            // Reiniciar correlativos
            st.executeUpdate("UPDATE correlativo SET ultimo = 0");
            st.executeUpdate("SET FOREIGN_KEY_CHECKS = 1");

            System.out.println("🧹 Tablas reiniciadas y correlativos en 0");
        } catch (Exception e) {
            System.out.println("❌ Error reset tablas: " + e.getMessage());
        }
    }
}