package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton para gestionar la conexión a la base de datos MySQL.
 * Carga la configuración desde config.properties (en el classpath).
 */
public class DatabaseConnection {
 
    private static DatabaseConnection instancia;
    private Connection conexion;
    private String url;
    private String user;
    private String password;
 
    private DatabaseConnection() {
        try {
            cargarConfiguracion();
            conexion = DriverManager.getConnection(url, user, password);
            System.out.println("✔ Conexión exitosa a la BD");
        } catch (Exception e) {
            System.out.println("❌ Error de conexión: " + e.getMessage());
        }
    }
 
    private void cargarConfiguracion() throws Exception {
        Properties props = new Properties();
        String configFile = "config.properties";
 
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(configFile)) {
            if (input == null) {
                System.out.println("⚠ No se encontró " + configFile + " en el classpath. Usando valores por defecto.");
                url = "jdbc:mysql://localhost:3306/mediateca?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
                user = "root";
                password = "";
                return;
            }
            props.load(input);
            url = props.getProperty("db.url",
                    "jdbc:mysql://localhost:3306/mediateca?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true");
            user = props.getProperty("db.user", "root");
            password = props.getProperty("db.password", "");
        }
    }
 
    public static synchronized DatabaseConnection getInstancia() {
        if (instancia == null) {
            instancia = new DatabaseConnection();
        }
        return instancia;
    }
 
    /**
     * Devuelve la conexión activa. Si está cerrada, la re-abre.
     */
    public Connection getConexion() {
        try {
            if (conexion == null || conexion.isClosed()) {
                conexion = DriverManager.getConnection(url, user, password);
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al obtener conexión: " + e.getMessage());
        }
        return conexion;
    }
 
    public void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("✔ Conexión cerrada");
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al cerrar conexión: " + e.getMessage());
        }
    }
}