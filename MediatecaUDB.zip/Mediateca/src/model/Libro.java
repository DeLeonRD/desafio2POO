package model;

/**
 * Representa un libro. Mapea la tabla `libro`.
 * Hereda de MaterialEscrito (id, codigo, titulo, unidades, editorial).
 * Agrega: autor, numeroPaginas, isbn, anioPublicacion.
 */
public class Libro extends MaterialEscrito {

    private String autor;
    private int numeroPaginas;
    private String isbn;
    private int anioPublicacion;

    public Libro() {
        setTipoMaterial("LIBRO");
    }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public int getNumeroPaginas() { return numeroPaginas; }
    public void setNumeroPaginas(int n) { this.numeroPaginas = n; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public int getAnioPublicacion() { return anioPublicacion; }
    public void setAnioPublicacion(int a) { this.anioPublicacion = a; }

    @Override
    public String toString() {
        return "Libro{id=" + getId() +
                ", codigo='" + getCodigoIdentificacion() + '\'' +
                ", titulo='" + getTitulo() + '\'' +
                ", autor='" + autor + '\'' +
                ", editorial='" + getEditorial() + '\'' +
                ", paginas=" + numeroPaginas +
                ", isbn='" + isbn + '\'' +
                ", anio=" + anioPublicacion +
                ", unidades=" + getUnidadesDisponibles() + '}';
    }
}