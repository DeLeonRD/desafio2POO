package model;

/**
 * Material escrito. Mapea la tabla `material_escrito`.
 * Hereda todos los campos de Material y agrega `editorial`.
 * Es clase base para Libro y Revista.
 */
public class MaterialEscrito extends Material {
 
    protected String editorial;
 
    public MaterialEscrito() {
    }
 
    public String getEditorial() { return editorial; }
    public void setEditorial(String editorial) { this.editorial = editorial; }
 
    @Override
    public String toString() {
        return "MaterialEscrito{id=" + getId() +
                ", titulo='" + getTitulo() + '\'' +
                ", editorial='" + editorial + '\'' + '}';
    }
}