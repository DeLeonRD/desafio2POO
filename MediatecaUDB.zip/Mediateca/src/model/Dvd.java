package model;

/**
 * Representa un DVD. Mapea la tabla `dvd`.
 * Hereda de MaterialAudiovisual (id, codigo, titulo, unidades, duracion, genero).
 * Agrega: director.
 */
public class Dvd extends MaterialAudiovisual {

    private String director;

    public Dvd() {
        setTipoMaterial("DVD");
    }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    @Override
    public String toString() {
        return "Dvd{id=" + getId() +
                ", codigo='" + getCodigoIdentificacion() + '\'' +
                ", titulo='" + getTitulo() + '\'' +
                ", director='" + director + '\'' +
                ", duracion='" + getDuracion() + '\'' +
                ", genero='" + getGenero() + '\'' +
                ", unidades=" + getUnidadesDisponibles() + '}';
    }
}