package model;

/**
 * Representa un CD de audio. Mapea la tabla `cd_audio`.
 * Hereda de MaterialAudiovisual (id, codigo, titulo, unidades, duracion, genero).
 * Agrega: artista, numeroCanciones.
 */
public class CdAudio extends MaterialAudiovisual {

    private String artista;
    private int numeroCanciones;

    public CdAudio() {
        setTipoMaterial("CD_AUDIO");
    }

    public String getArtista() { return artista; }
    public void setArtista(String artista) { this.artista = artista; }

    public int getNumeroCanciones() { return numeroCanciones; }
    public void setNumeroCanciones(int n) { this.numeroCanciones = n; }

    @Override
    public String toString() {
        return "CdAudio{id=" + getId() +
                ", codigo='" + getCodigoIdentificacion() + '\'' +
                ", titulo='" + getTitulo() + '\'' +
                ", artista='" + artista + '\'' +
                ", duracion='" + getDuracion() + '\'' +
                ", genero='" + getGenero() + '\'' +
                ", canciones=" + numeroCanciones +
                ", unidades=" + getUnidadesDisponibles() + '}';
    }
}