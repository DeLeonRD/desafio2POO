package model;

import java.sql.Date;

/**
 * Representa una revista. Mapea la tabla `revista`.
 * Hereda de MaterialEscrito (por la jerarquía de la BD: revista es material escrito).
 * Agrega: periodicidad y fechaPublicacion.
 *
 * Valores válidos de periodicidad (según ENUM de la BD):
 *   SEMANAL, QUINCENAL, MENSUAL, BIMESTRAL,
 *   TRIMESTRAL, SEMESTRAL, ANUAL
 */
public class Revista extends MaterialEscrito {

    private String periodicidad;
    private Date fechaPublicacion;

    public Revista() {
        setTipoMaterial("REVISTA");
    }

    public String getPeriodicidad() { return periodicidad; }
    public void setPeriodicidad(String p) { this.periodicidad = p; }

    public Date getFechaPublicacion() { return fechaPublicacion; }
    public void setFechaPublicacion(Date f) { this.fechaPublicacion = f; }

    @Override
    public String toString() {
        return "Revista{id=" + getId() +
                ", codigo='" + getCodigoIdentificacion() + '\'' +
                ", titulo='" + getTitulo() + '\'' +
                ", editorial='" + getEditorial() + '\'' +
                ", periodicidad='" + periodicidad + '\'' +
                ", fechaPublicacion=" + fechaPublicacion +
                ", unidades=" + getUnidadesDisponibles() + '}';
    }
}