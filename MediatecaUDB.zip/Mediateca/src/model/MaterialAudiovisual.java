package model;

/**
 * Material audiovisual. Mapea la tabla `material_audiovisual`.
 * Hereda de Material y agrega `duracion` (formato HH:MM:SS) y `genero`.
 * Es clase base para CdAudio y Dvd.
 */
public class MaterialAudiovisual extends Material {
 
    protected String duracion; // formato HH:MM:SS
    protected String genero;
 
    public MaterialAudiovisual() {
    }
 
    public String getDuracion() { return duracion; }
    public void setDuracion(String duracion) { this.duracion = duracion; }
 
    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }
 
    @Override
    public String toString() {
        return "MaterialAudiovisual{id=" + getId() +
                ", titulo='" + getTitulo() + '\'' +
                ", duracion='" + duracion + '\'' +
                ", genero='" + genero + '\'' + '}';
    }
}