package model;

import java.sql.Timestamp;
import java.util.Objects;

public class Material {
    protected int id;                      // id_material
    protected String codigoIdentificacion; // ej: LIB00001
    protected String titulo;
    protected int unidadesDisponibles;
    protected String tipoMaterial;         // LIBRO, REVISTA, CD_AUDIO, DVD
    protected Timestamp fechaRegistro;
     
            
    public Material() {}
    
    public Material(int id, String codigoIdentificacion, String titulo,
                    int unidadesDisponibles, String tipoMaterial) {
        this.id = id;
        this.codigoIdentificacion = codigoIdentificacion;
        this.titulo = titulo;
        this.unidadesDisponibles = unidadesDisponibles;
        this.tipoMaterial = tipoMaterial;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
 
    public String getCodigoIdentificacion() { return codigoIdentificacion; }
    public void setCodigoIdentificacion(String c) { this.codigoIdentificacion = c; }
 
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
 
    public int getUnidadesDisponibles() { return unidadesDisponibles; }
    public void setUnidadesDisponibles(int u) { this.unidadesDisponibles = u; }
 
    public String getTipoMaterial() { return tipoMaterial; }
    public void setTipoMaterial(String t) { this.tipoMaterial = t; }
 
    public Timestamp getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(Timestamp f) { this.fechaRegistro = f; }
    
   
    
    @Override
    public String toString() {
        return "Material{id=" + id +
                ", codigo='" + codigoIdentificacion + '\'' +
                ", titulo='" + titulo + '\'' +
                ", unidades=" + unidadesDisponibles +
                ", tipo='" + tipoMaterial + '\'' + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Material)) return false;
        Material m = (Material) o;
        return id == m.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}